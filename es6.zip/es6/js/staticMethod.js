/*
Static Method is one of the useful method introduce in ES6.
*/

class Test{
	static newtest(){
		console.log("success");
	}
}

Test.newtest();

//Output is success


/*
Explaination : We are not at all using "function" keyword but we can access function using "static"

in from that class.
*/